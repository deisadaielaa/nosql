package com.example.asistentultau

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
