import 'package:flutter/material.dart';
import 'profilepage.dart';

class ImagePage extends StatelessWidget {

  final String title;

  ImagePage(this.title);
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Image App Demo',
      theme: ThemeData(
        primaryColor: Colors.black,
      ),
      home: MyHomePage(),
    );
  }
}