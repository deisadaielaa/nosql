import 'package:flutter/material.dart';
import 'saleshomepage.dart';


class ChartPage extends StatelessWidget {

  final String title;

  ChartPage(this.title);
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Firestore Chart',
      theme: ThemeData(
        primaryColor: Colors.redAccent,
      ),
      //home: TaskHomePage(),
      home:SalesHomePage(),
    );
  }
}