import 'package:flutter/material.dart';
import 'package:asistentultau/dashboardsecond.dart';

class TherdPage extends StatelessWidget {

  final String title;

  TherdPage(this.title);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: DashboardSecondPage(
            currencyVal: 0.0,
            convertedCurrency: 0.0,
            currencyone: 'USD',
            currencytwo: 'RUB',
            isWhite: false));
  }
}